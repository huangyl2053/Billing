-- --------------------------------------------------------
-- 主机:                           localhost
-- 服务器版本:                        5.7.17-log - MySQL Community Server (GPL)
-- 服务器操作系统:                      Win32
-- HeidiSQL 版本:                  9.2.0.4947
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 导出 billing 的数据库结构
CREATE DATABASE IF NOT EXISTS `billing` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `billing`;


-- 导出  表 billing.bill 结构
CREATE TABLE IF NOT EXISTS `bill` (
  `datetime` char(50) NOT NULL,
  `tip1text` char(50) DEFAULT NULL,
  `tip1` char(50) DEFAULT NULL,
  `tip2text` char(50) DEFAULT NULL,
  `tip2` char(50) DEFAULT NULL,
  `tip3text` char(50) DEFAULT NULL,
  `tip3` char(50) DEFAULT NULL,
  `total` char(50) DEFAULT NULL,
  `today` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`datetime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  billing.bill 的数据：~3 rows (大约)
DELETE FROM `bill`;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` (`datetime`, `tip1text`, `tip1`, `tip2text`, `tip2`, `tip3text`, `tip3`, `total`, `today`) VALUES
	('2017/01/03', 'a', '1', 'b', '2', 'c', '3', '6', 'd'),
	('2017/01/04', NULL, '9', NULL, '15', NULL, '19', '43', NULL);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
